'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useState } from 'react';

export function QueryProvider({ children }: { children: React.ReactNode }) {
    const [queryClient] = useState(
        () =>
            new QueryClient({
                defaultOptions: {
                    queries: {
                        staleTime: 60 * 1000, // 1 minute - data is fresh for 1 minute
                        gcTime: 5 * 60 * 1000, // 5 minutes - cache for 5 minutes
                        refetchOnWindowFocus: false,
                        retry: 1,
                        refetchOnMount: false, // Don't refetch on mount if data is fresh
                    },
                    mutations: {
                        retry: 1,
                    },
                },
            })
    );

    return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>;
}
